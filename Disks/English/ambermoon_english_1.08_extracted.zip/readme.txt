Ambermoon English 1.08 by Pyrdacor
==================================

This version is based on the official english release 1.07.

It also includes the following patches:

- Meynaf english patch


Additional changes in 1.08
==========================

- Sansrie's key will work now in Sansrie's tunnel.
- The mysterious party member golem which appeared at 0:00 inside the temple
  of gala is now fixed and will appear as a regular monster group (4 golems)
  on the map.
- Reg the hill giant is now flagged as 'Boss' so he is now immune to spells
  like Fear or Petrified.
- Two parts of the Lyramion world map are fixed so that there is no longer
  a strange changing in fog of war.
- Gryban will now spawn in godsbane when you dismiss him from the party.
- Fixed two corrupted wind gates where the graphics were messed up after
  repairing.
- It is now possible to teleport back to the first floor in Gadlon.
- Fixed a button in the bandits' house cellar.
- Fixed all plants on the surface of Kire's moon. They will now all be
  collectable after you talked about plants with Asrub.
- Fixed a text popup in Nalven's magical school in Burnville when you
  approach the door to right.
- Added two missing text popups in the secret Thalion Office.
- The windgate at 271, 564 is no longer usable when it is broken.
- Added floor texture to the town of S'Angrila on Morag.
- Fixed wrong spawn direction when going from Luminor's tower level 4 to 3.
- Changed all wrong occurences of the fixed words "HE" and "HIS" to the
  placeholders. This way the correct sex is used for female main characters.
- Renamed monster "ENERGIEGLOBE" to "ENERGY GLOBE".
- Changed Gryban start exp to 114250 (which is the minimum exp for his level).
- Changed text in Pelanis' palace so that it mentions the word "CONCERNS"
  which is a keyword for Pelanis.
- Improved text of a crystal sphere in Gala's temple.
- Fixed wrongly stated closing hour in Alkem's tower.
- Fixed a crash in the conversation with Ketnar.
- Fixed a crash when approaching Randor's general store in Dor Grestin while
  it's closed.
- Fixed some more typos and names.


About the author
================

All fixes were done by Pyrdacor (trobt@web.de).
You can also visit my github site at https://github.com/Pyrdacor.