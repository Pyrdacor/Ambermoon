These folder contain all english texts of Ambermoon.

XMap_data.amb
#############

Contains the go-to point names for cities. For each
relevant city map there is a folder with the map index.
1Map_data.amb is therefore empty as it contains all
Lyramion world maps and there are no cities of course.


XMap_texts.amb
##############

Contains all map texts. Note that 2Map_texts.amb also
contains folders for maps 1 to 256 which are part of
1Map_texts.amb. Ambermoon stores texts this way and
adds empty files for maps that are not relevant. The
file containers have to mechanism for file index
assigning so for example text file 257 has to be the
257th entry inside the container. So skip to 256 ($FF)
for 2Map_texts.amb and to 300 ($12C) for 3Map_texts.amb.
Texts starting at 400 ($190) are part of 2Map_texts.amb.
Leave it this way:
1Map_texts.amb: 1..256 (Lyramion world maps)
2Map_texts.amb: 257..299 and 400..1023 (All Lyramion non-world maps and all Morag maps)
3Map_texts.amb: 300..399 (All forest moon maps)


Dict.amb
########

Contains all dictionary words you can choose in
conversations. They are also used as keywords and for
riddlemouths. Pre 1.14 the file was called Dictionary.german
or Dictionary.english.


Monster_char.amb
################

Contains all monster names. Each file stands for a monster
with the same id. This was called Monster_char_data.amb
pre 1.14. A few monster names like "Sansri" shouldn't be
touched but most should be translated.


NPC_char.amb
############

Contains all NPC names. Each file stands for an NPC
with the same id.


NPC_texts.amb
#############

Contains all NPC texts. Each folder stands for an NPC
with the same id. The files are the texts the NPC can
use. Most NPC names shouldn't be touched but there are
some like "Grandfather" or "Father Anthony" which
should be translated.


Object_texts.amb
################

Contains all object texts. Those are basically the
texts of text scrolls. They are divided into categories
which are represented by the folders. The text files then
represent the text index inside those categories. Each
text scroll item can specify two ids (8-bit each) to
express the category and the text index.


Objects.amb
###########

Contains all item names. This file was introduced in
1.14 to move the data of all items out of the
executables AM2_CPU and AM2_BLIT. Each text file
holds the name of the item with the same id.


Party_char.amb
##############

Contains all party member names. Each file stands for
a party member with the same id. Index 1 is always the
hero and the name defaults to "Thalion". However it is
of course replaced for new games by the chosen name so
it doesn't make sense to translate or edit the name.
The only party member name of relevance is Tar the dark
as the part "the dark" should be translated.


Party_texts.amb
###############

It is basically the same as NPC_texts.amb but for
conversations with party members (also if they are
not inside the party). The folder 001 is empty as
it stands for the hero and you can't talk to yourself.


Place_data
##########

This contains all place names. Places are merchants,
sages, blacksmiths, healers and so on.


Text.amb
########

This file was added in 1.14 to move all in-game texts
out of the executables. This file contains all error
messages, UI texts, in-game messages as well as all
kind of names for classes, races, spells and so on.

Some special care is needed for some texts. See below.


Short names
***********
There are short names for attributes and skills.
Ensure that they all use 3 letters


FormatMessages
**************
Some of them use placeholders like {0} or {1}. They will
be replaced by texts at runtime so leave them in there.
Also ensure, that the whole text keeps its structure.
This means if it is "text{0}text{1}text" is has to be
like that afterwards. Things like "text{0}text{1}" or
"text{0}{1}text" will mess up the in-game texts or even
crash the importer.

Texts 004.txt and 005.txt are special. Those are
multi-line texts that end with a marker for a mouse click.
Always keep the number of lines as it is. You can move
things over to the next line and also use the blank lines
for text but the total amount of lines must stay as it was!
Also never use or change the last line {{Click}}!
And last but not least, try to keep line length below or
equal to 48. Those text blocks are displayed in a window
which is not much larger. Maybe a length of 50 might work
as well but 48 is a safe value as the english text uses
it too.

UITexts
*******
There are placeholders of the form 01, 012, etc.
Leave them as they are. Don't rename them and don't
change the number of digits. The game uses fixed
length anyway so changing the text wouldn't change
anything. You can however change their position.
Note that some UI texts are used in the same window
and it is often desired to place the colon (:) at the
same offset. For example the text "  HANDS: 0" and
"FINGERS: 0" are used together in the item window.
Note the two blanks at the beginning of "  HANDS: 0".
It ensures that the colons are on the same position
and that the pre-colon text is right-aligned.

There is the special text 012.txt which represents
the content of the compass. Don't change the text
length and also keep the two blanks at the end!
Otherwise the display will be messed up ingame.
Always use a single letter for north, east, south
and west and 3 letters (might be of the form X-X)
for the diagonal directions like north-east etc.

General
*******
Don't add new text files to Text.amb. The file is
closely coupled to what the game expects. New texts
would require code changes to the game.


Exported by Pyrdacor - May the force ... 2022 :)
